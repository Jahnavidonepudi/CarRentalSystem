package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeEach;

import dao.ICarLeaseRepositoryImpl;
import entity.model.Car;
import entity.model.Customer;
import entity.model.Lease;
import exception.CarNotFoundException;
import exception.LeaseNotFoundException;

import java.util.Date;
import java.util.List;

public class ICarLeaseRepositoryImplTest {

    private ICarLeaseRepositoryImpl repository;

        @BeforeEach
        public void setUp() {
            repository = new ICarLeaseRepositoryImpl();
        }

        @Test
        public void testAddCar() {

            Car car = new Car();
            car.setCarID(1);
            car.setMake("Toyota");
            car.setModel("Camry");
            car.setYear(2020);
            car.setStatus("not available");
            car.setDailyRate(50);
            car.setPassengerCapacity(5);
            car.setEngineCapacity(3);
            repository.addCar(car);

        }

        @Test
        public void testAddLease() {

            
        	Lease lease = new Lease();
            lease.setLeaseID(1);
            lease.setCustomerID(1);
            lease.setCarID(1);
            Date startDate = new Date(2023 - 2023, 0, 1); 
            Date endDate = new Date(2023 - 2023, 0, 10); 
            repository.addCar(lease);

        }
        @Test
        public void testListActiveLeases() {

            repository.listActiveLeases1();
        }
      

    	@Test
        public void testGetLeaseBy() throws LeaseNotFoundException {

            repository.getLeaseBy(1);
        }

       

        
    }