package dao;

import entity.model.Car;
import entity.model.Customer;
import entity.model.Lease;
import exception.*;
import util.DBConnUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ICarLeaseRepositoryImpl implements ICarLeaseRepository {
    private Connection connection;

    public ICarLeaseRepositoryImpl() {
        this.connection = DBConnUtil.getConnect();
    }

    // Car Management
    @Override
    public void addCar(Car car) {
        String query = "Insert into Car (make, model, year, dailyRate, status, passengerCapacity, engineCapacity) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, car.getMake());
            pstmt.setString(2, car.getModel());
            pstmt.setInt(3, car.getYear());
            pstmt.setDouble(4, car.getDailyRate());
            pstmt.setString(5, car.getStatus());
            pstmt.setInt(6, car.getPassengerCapacity());
            pstmt.setDouble(7, car.getEngineCapacity());
            pstmt.executeUpdate();
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
    }

    @Override
    public void removeCar(int carID) {
        String query = "DELETE FROM Car WHERE CarID = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, carID);
            pstmt.executeUpdate();
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
    }

    @Override
    public List<Car> listAvailableCars() {
        List<Car> cars = new ArrayList<>();
        String query = "SELECT * FROM Car WHERE status = 'available'";
        try (Statement stmt = connection.createStatement();
        	ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                cars.add(new Car(
                rs.getInt("carID"), 
                rs.getString("make"), 
                rs.getString("model"), 
                rs.getInt("year"), 
                rs.getDouble("dailyRate"), 
                rs.getString("status"), 
                rs.getInt("passengerCapacity"), 
                rs.getDouble("engineCapacity")));
            }
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
        return cars;
    }

    @Override
    public List<Car> listRentedCars() {
        List<Car> cars = new ArrayList<>();
        String query = "SELECT * FROM Car WHERE status = 'notAvailable'";
        try (Statement stmt = connection.createStatement();
        	ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                cars.add(new Car( 		
               rs.getInt("carID"), 
               rs.getString("make"), 
               rs.getString("model"), 
               rs.getInt("year"), 
               rs.getDouble("dailyRate"), 
               rs.getString("status"), 
               rs.getInt("passengerCapacity"),
               rs.getDouble("engineCapacity")));
            }
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
        return cars;
    }

    @Override
    public Car findCarById(int CarID) throws CarNotFoundException {
        String query = "SELECT * FROM Car WHERE carID = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, CarID); // Setting the parameter
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Car(
                    rs.getInt("carID"), 
                    rs.getString("make"), 
                    rs.getString("model"), 
                    rs.getInt("year"), 
                    rs.getDouble("dailyRate"), 
                    rs.getString("status"), 
                    rs.getInt("passengerCapacity"), 
                    rs.getDouble("engineCapacity"));
            } else {
                throw new CarNotFoundException("Car with ID " + CarID + " not found.");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return null;
        }
    }


    // Customer Management
    @Override
    public void addCustomer(Customer customer) {
        String query = "INSERT INTO Customer (firstName, lastName, email, phoneNumber) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, customer.getFirstName());
            pstmt.setString(2, customer.getLastName());
            pstmt.setString(3, customer.getEmail());
            pstmt.setString(4, customer.getPhoneNumber());
            pstmt.executeUpdate();
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
    }

    @Override
    public void removeCustomer(int customerID) {
        String query = "DELETE FROM Customer WHERE customerID = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, customerID);
            pstmt.executeUpdate();
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
    }

    @Override
    public List<Customer> listCustomers() {
        List<Customer> customers = new ArrayList<>();
        String query = "SELECT * FROM Customer";
        try (PreparedStatement pstmt = connection.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                customers.add(new Customer(
                    rs.getInt("customerID"),
                    rs.getString("firstName"), 
                    rs.getString("lastName"), 
                    rs.getString("email"), 
                    rs.getString("phoneNumber")));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return customers;
    }


    @Override
    public Customer findCustomerById(int customerID) {
        String query = "SELECT * FROM Customer WHERE customerID = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, customerID);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Customer(
                rs.getInt("customerID"), 
                rs.getString("firstName"), 
                rs.getString("lastName"), 
                rs.getString("email"), 
                rs.getString("phoneNumber"));
            } else {
                throw new CustomerNotFoundException("Customer with ID " + customerID + " not found.");
            }
        } catch (Exception e) {
        	System.out.println(e.getMessage());
            return null;
        }
    }

    // Lease Management
    @Override
    public Lease createLease(int customerID, int carID, Date startDate, Date endDate) {
        String query = "INSERT INTO Lease (carID, customerID, startDate, endDate, type) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, carID);
            pstmt.setInt(2, customerID);
            pstmt.setDate(3, new java.sql.Date(startDate.getTime()));
            pstmt.setDate(4, new java.sql.Date(endDate.getTime()));
            pstmt.setString(5, "DailyLease");
            pstmt.executeUpdate();
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
        return null;
    }

    @Override
    public void returnCar(int leaseID) {
        String query = "UPDATE Car SET status = 'available' WHERE carID = (SELECT carID FROM Lease WHERE leaseID = ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, leaseID);
            pstmt.executeUpdate();
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
    }

    @Override
    public List<Lease> listActiveLeases() {
        List<Lease> leases = new ArrayList<>();
        String query = "SELECT * FROM Lease WHERE endDate IS NULL";
        try (PreparedStatement pstmt = connection.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                leases.add(new Lease(
                    rs.getInt("leaseID"), 
                    rs.getInt("carID"), 
                    rs.getInt("customerID"), 
                    rs.getDate("startDate"), 
                    rs.getDate("endDate"), 
                    rs.getString("type")));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return leases;
    }

    @Override
    public List<Lease> listLeaseHistory() {
        List<Lease> leases = new ArrayList<>();
        String query = "SELECT * FROM Lease";
        try (PreparedStatement pstmt = connection.prepareStatement(query);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                leases.add(new Lease(
                    rs.getInt("leaseID"), 
                    rs.getInt("carID"), 
                    rs.getInt("customerID"), 
                    rs.getDate("startDate"), 
                    rs.getDate("endDate"), 
                    rs.getString("type")));
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return leases;
    }

    

    // Payment Handling
    @Override
    public void recordPayment(Lease lease, double amount) {
        String query = "INSERT INTO Payment (leaseID, paymentDate, amount) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, lease.getLeaseID());
            pstmt.setDate(2, new java.sql.Date(new Date().getTime()));
            pstmt.setDouble(3, amount);
            pstmt.executeUpdate();
        } catch (Exception e) {
        	System.out.println(e.getMessage());
        }
    }

	public Lease getLeaseBy(int i) {
		return null;
		// TODO Auto-generated method stub
		
	}
	
    public void listActiveLeases1() {
    	
    }


	public void addLease(Lease lease) {
		// TODO Auto-generated method stub
		
	}
    

}
	